import React, { useState } from 'react';

const AppointmentFormSection = () => {
  const [formData, setFormData] = useState({
    fullName: '',
    companyEmail: '',
    companyName: '',
    segment: '',
    challenge: '',
    phone: '',
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prevData => ({ ...prevData, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    // Placeholder para integração com n8n/Google Sheets
    // Aqui você faria a chamada para o webhook do n8n
    console.log('Dados do formulário:', formData);
    alert('Solicitação de agendamento enviada! Entraremos em contato em breve.');
    // Limpar formulário após envio (opcional)
    setFormData({
      fullName: '',
      companyEmail: '',
      companyName: '',
      segment: '',
      challenge: '',
      phone: '',
    });
  };

  return (
    <section id="formulario-agendamento" className="py-16 md:py-24 bg-cinza-escuro text-branco">
      <div className="container mx-auto px-6">
        <h2 className="text-3xl md:text-4xl font-bold font-poppins text-center mb-12 md:mb-16">
          Agende Sua Demonstração Gratuita
        </h2>
        <form onSubmit={handleSubmit} className="max-w-xl mx-auto bg-gray-800 p-8 rounded-lg shadow-xl">
          <div className="mb-6">
            <label htmlFor="fullName" className="block font-roboto-mono text-sm font-medium mb-2">Nome Completo</label>
            <input type="text" name="fullName" id="fullName" value={formData.fullName} onChange={handleChange} required className="w-full p-3 bg-gray-700 rounded-md focus:ring-azul-neon focus:border-azul-neon" />
          </div>
          <div className="mb-6">
            <label htmlFor="companyEmail" className="block font-roboto-mono text-sm font-medium mb-2">E-mail Corporativo</label>
            <input type="email" name="companyEmail" id="companyEmail" value={formData.companyEmail} onChange={handleChange} required className="w-full p-3 bg-gray-700 rounded-md focus:ring-azul-neon focus:border-azul-neon" />
          </div>
          <div className="mb-6">
            <label htmlFor="companyName" className="block font-roboto-mono text-sm font-medium mb-2">Nome da Empresa</label>
            <input type="text" name="companyName" id="companyName" value={formData.companyName} onChange={handleChange} required className="w-full p-3 bg-gray-700 rounded-md focus:ring-azul-neon focus:border-azul-neon" />
          </div>
          <div className="mb-6">
            <label htmlFor="segment" className="block font-roboto-mono text-sm font-medium mb-2">Segmento de Atuação</label>
            <select name="segment" id="segment" value={formData.segment} onChange={handleChange} className="w-full p-3 bg-gray-700 rounded-md focus:ring-azul-neon focus:border-azul-neon">
              <option value="">Selecione o segmento</option>
              <option value="infoprodutor">Infoprodutor</option>
              <option value="ecommerce">E-commerce</option>
              <option value="servicos_b2b">Serviços B2B</option>
              <option value="servicos_b2c">Serviços B2C</option>
              <option value="pme">PME (Pequena/Média Empresa)</option>
              <option value="profissional_liberal">Profissional Liberal</option>
              <option value="outro">Outro</option>
            </select>
          </div>
          <div className="mb-6">
            <label htmlFor="challenge" className="block font-roboto-mono text-sm font-medium mb-2">Principal Desafio Atual (Opcional)</label>
            <textarea name="challenge" id="challenge" value={formData.challenge} onChange={handleChange} rows={3} className="w-full p-3 bg-gray-700 rounded-md focus:ring-azul-neon focus:border-azul-neon"></textarea>
          </div>
          <div className="mb-8">
            <label htmlFor="phone" className="block font-roboto-mono text-sm font-medium mb-2">Melhor Telefone para Contato (com WhatsApp)</label>
            <input type="tel" name="phone" id="phone" value={formData.phone} onChange={handleChange} required className="w-full p-3 bg-gray-700 rounded-md focus:ring-azul-neon focus:border-azul-neon" placeholder="+55 (XX) XXXXX-XXXX" />
          </div>
          <button type="submit" className="w-full bg-azul-neon text-branco font-roboto-mono py-3 px-6 rounded-md text-lg hover:bg-roxo-vibrante transition-colors duration-300">
            Solicitar Agendamento
          </button>
          <p className="text-xs font-roboto-mono text-gray-400 mt-4 text-center">
            Ao enviar, você concorda com nossa <a href="/politica-de-privacidade" className="underline hover:text-azul-neon">Política de Privacidade</a>.
          </p>
        </form>
      </div>
    </section>
  );
};

export default AppointmentFormSection;

