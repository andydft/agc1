import React from 'react';

// Placeholder para dados de testemunhos e cases
const testimonials = [
  {
    id: 1,
    name: 'Cliente Satisfeito 1',
    company: 'Empresa Exemplo A',
    quote: 'A AGC+ transformou nossa maneira de captar leads! Resultados incríveis em pouco tempo.',
    image: '/images/placeholder-client-1.jpg', // Substituir por imagem real ou remover
  },
  {
    id: 2,
    name: 'Cliente Satisfeito 2',
    company: 'Negócio Inovador B',
    quote: 'O nível de automação que alcançamos com a AGC+ é impressionante. Recomendo!',
    image: '/images/placeholder-client-2.jpg', // Substituir por imagem real ou remover
  },
];

const miniCases = [
  {
    id: 1,
    clientLogo: '/images/logo-cliente-placeholder.png', // Substituir por logo real
    challenge: 'Baixa qualificação de leads e alto custo por aquisição.',
    solution: 'Implementação de funil de automação com n8n e segmentação avançada.',
    result: '+30% Leads Qualificados, -50% Custo por Aquisição',
  },
];

const SocialProofSection = () => {
  const hasTestimonials = testimonials.length > 0;
  const hasCases = miniCases.length > 0;

  return (
    <section id="prova-social" className="py-16 md:py-24 bg-gray-800 text-branco">
      <div className="container mx-auto px-6">
        <h2 className="text-3xl md:text-4xl font-bold font-poppins text-center mb-12 md:mb-16 text-azul-neon">
          Quem Confia na AGC+ Transforma Seus Resultados.
        </h2>

        {hasTestimonials && (
          <div className="mb-16">
            <h3 className="text-2xl font-semibold font-poppins text-center mb-8">Depoimentos de Clientes</h3>
            <div className="grid md:grid-cols-2 gap-8">
              {testimonials.map((testimonial) => (
                <div key={testimonial.id} className="bg-cinza-escuro p-6 rounded-lg shadow-lg flex flex-col items-center text-center">
                  {/* Idealmente, adicionar imagem do cliente aqui */}
                  {/* <img src={testimonial.image} alt={testimonial.name} className="w-24 h-24 rounded-full mb-4 object-cover" /> */}
                  <p className="font-roboto-mono text-lg mb-4"><em>"{testimonial.quote}"</em></p>
                  <p className="font-poppins font-semibold">{testimonial.name}</p>
                  <p className="font-roboto-mono text-sm text-gray-400">{testimonial.company}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {hasCases && (
          <div className="mb-16">
            <h3 className="text-2xl font-semibold font-poppins text-center mb-8">Cases de Sucesso</h3>
            {miniCases.map((caseItem) => (
              <div key={caseItem.id} className="bg-cinza-escuro p-6 rounded-lg shadow-lg mb-8 max-w-2xl mx-auto">
                {/* Idealmente, adicionar logo do cliente aqui */}
                {/* <img src={caseItem.clientLogo} alt="Logo Cliente" className="h-12 mb-4 mx-auto" /> */}
                <h4 className="font-poppins text-xl font-semibold mb-2">Desafio:</h4>
                <p className="font-roboto-mono mb-3">{caseItem.challenge}</p>
                <h4 className="font-poppins text-xl font-semibold mb-2">Solução AGC+:</h4>
                <p className="font-roboto-mono mb-3">{caseItem.solution}</p>
                <h4 className="font-poppins text-xl font-semibold mb-2 text-azul-neon">Resultado Principal:</h4>
                <p className="font-roboto-mono font-bold text-lg">{caseItem.result}</p>
              </div>
            ))}
          </div>
        )}

        {!hasTestimonials && !hasCases && (
          <p className="font-roboto-mono text-xl text-center">
            Em breve: histórias de sucesso de clientes como você. Seja um dos nossos próximos cases de sucesso!
          </p>
        )}
      </div>
    </section>
  );
};

export default SocialProofSection;
