import React from 'react';

const FinalCTASection = () => {
  return (
    <section id="cta-final" className="py-16 md:py-24 bg-gradiente-agc text-branco">
      <div className="container mx-auto px-6 text-center">
        <h2 className="text-3xl md:text-4xl font-bold font-poppins mb-6">
          Pronto para Simplificar Sua Escalada e Ver Resultados Reais?
        </h2>
        <p className="text-lg md:text-xl font-roboto-mono mb-10 max-w-2xl mx-auto">
          Agende uma demonstração gratuita e personalizada. Vamos mostrar na prática como a automação inteligente da AGC+ pode revolucionar seu marketing e suas vendas.
        </p>
        <button className="bg-branco text-azul-neon font-roboto-mono py-3 px-8 rounded-md text-lg hover:bg-gray-200 hover:text-roxo-vibrante transition-colors duration-300 shadow-lg">
          Agendar Minha Demonstração Agora!
        </button>
        <p className="mt-6 text-sm font-roboto-mono text-gray-300">
          Sem compromisso. Apenas insights valiosos para o seu negócio.
        </p>
      </div>
    </section>
  );
};

export default FinalCTASection;
