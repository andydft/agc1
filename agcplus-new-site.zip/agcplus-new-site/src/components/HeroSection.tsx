import React from 'react';

const HeroSection = () => {
  return (
    <section id="hero" className="min-h-screen flex items-center justify-center bg-gradiente-agc text-branco pt-20 md:pt-0">
      <div className="container mx-auto px-6 text-center">
        <h1 className="text-4xl md:text-6xl font-bold font-poppins mb-6">
          Sua Empresa no Piloto Automático para Resultados Reais: Descubra o Poder da AGC+.
        </h1>
        <p className="text-lg md:text-xl font-roboto-mono mb-10 max-w-3xl mx-auto">
          Cansado de processos manuais que limitam suas vendas? Transformamos sua operação digital, simplificando a complexidade para você focar no que realmente importa.
        </p>
        <button className="bg-azul-neon text-branco font-roboto-mono py-3 px-8 rounded-md text-lg hover:bg-roxo-vibrante transition-colors duration-300">
          Quero Agendar Minha Demonstração Gratuita
        </button>
        <p className="mt-6 text-sm font-roboto-mono text-gray-300">
          Junte-se a empresas que já estão revolucionando seus resultados.
        </p>
        {/* Adicionar elementos geométricos sutis e animações leves conforme o blueprint aqui */}
      </div>
    </section>
  );
};

export default HeroSection;
