import Link from 'next/link';

const Navbar = () => {
  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-cinza-escuro bg-opacity-90 backdrop-blur-md shadow-md">
      <div className="container mx-auto px-6 py-3 flex justify-between items-center">
        <div>
          {/* Logo AGC+ - Placeholder, substituir pela imagem/componente real do logo */}
          <Link href="/" className="text-2xl font-bold font-poppins text-branco">
            AGC+
          </Link>
        </div>
        <div className="hidden md:flex items-center space-x-4">
          {/* Links de Navegação - Opcional, conforme blueprint */}
          {/* <Link href="#servicos" className="text-branco hover:text-azul-neon font-roboto-mono">Serviços</Link>
          <Link href="#cases" className="text-branco hover:text-azul-neon font-roboto-mono">Cases</Link>
          <Link href="#blog" className="text-branco hover:text-azul-neon font-roboto-mono">Blog</Link> */}
        </div>
        <div>
          <button className="bg-azul-neon text-branco font-roboto-mono py-2 px-6 rounded-md hover:bg-roxo-vibrante transition-colors duration-300">
            Agendar Demonstração
          </button>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
