import React from 'react';
import Link from 'next/link';
import { Facebook, Instagram, Linkedin, Twitter } from 'lucide-react'; // Ícones de exemplo

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-cinza-escuro text-branco py-12 md:py-16">
      <div className="container mx-auto px-6">
        <div className="grid md:grid-cols-3 gap-8 mb-8 items-center">
          {/* Logo e Slogan */}
          <div className="md:col-span-1 flex flex-col items-center md:items-start">
            {/* Logo AGC+ - Placeholder */}
            <Link href="/" className="text-3xl font-bold font-poppins text-branco mb-2">
              AGC+
            </Link>
            <p className="font-roboto-mono text-sm text-gray-400 text-center md:text-left">
              Transformação digital sem complexidade: automação que entrega resultados.
            </p>
          </div>

          {/* Links Rápidos / Contato (Opcional) */}
          <div className="md:col-span-1 flex flex-col items-center">
            {/* <h4 className="font-poppins text-lg font-semibold mb-3">Links Úteis</h4>
            <ul className="space-y-2 font-roboto-mono text-sm">
              <li><Link href="#servicos" className="hover:text-azul-neon">Nossos Serviços</Link></li>
              <li><Link href="/blog" className="hover:text-azul-neon">Blog</Link></li>
              <li><Link href="/contato" className="hover:text-azul-neon">Contato</Link></li>
            </ul> */}
          </div>

          {/* Redes Sociais e Contato */}
          <div className="md:col-span-1 flex flex-col items-center md:items-end">
            <p className="font-roboto-mono text-sm mb-2 text-center md:text-right">contato@agcplus.com.br</p>
            {/* <p className="font-roboto-mono text-sm mb-4 text-center md:text-right">+55 (XX) XXXX-XXXX</p> */}
            <div className="flex space-x-4">
              <Link href="#" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-azul-neon">
                <Facebook size={24} />
              </Link>
              <Link href="#" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-azul-neon">
                <Instagram size={24} />
              </Link>
              <Link href="#" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-azul-neon">
                <Linkedin size={24} />
              </Link>
              <Link href="#" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-azul-neon">
                <Twitter size={24} />
              </Link>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-700 pt-8 flex flex-col md:flex-row justify-between items-center text-center md:text-left">
          <p className="font-roboto-mono text-xs text-gray-500 mb-4 md:mb-0">
            &copy; {currentYear} AGC+. Todos os direitos reservados.
          </p>
          <div className="font-roboto-mono text-xs text-gray-500 space-x-4">
            <Link href="/politica-de-privacidade" className="hover:text-azul-neon">Política de Privacidade</Link>
            <Link href="/termos-de-uso" className="hover:text-azul-neon">Termos de Uso</Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
