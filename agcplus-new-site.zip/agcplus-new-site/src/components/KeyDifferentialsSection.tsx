import React from 'react';
import { Award, Zap, BarChartBig } from 'lucide-react'; // Ícones de exemplo

const KeyDifferentialsSection = () => {
  const differentials = [
    {
      icon: <Award size={40} className="text-azul-neon mb-4" />,
      title: 'Integração Única n8n + Chatwoot no Brasil',
      text: 'Oferecemos uma sinergia poderosa entre automação avançada e comunicação humanizada, otimizando a jornada do seu cliente como nenhuma outra agência.',
    },
    {
      icon: <Zap size={40} className="text-azul-neon mb-4" />,
      title: 'Relatórios em Tempo Real, Decisões Ágeis',
      text: 'Chega de esperar por relatórios semanais. Com a AGC+, você acompanha a performance em tempo real e ajusta suas estratégias com a velocidade que o mercado exige.',
    },
    {
      icon: <BarChartBig size={40} className="text-azul-neon mb-4" />,
      title: 'Foco Absoluto em Resultados Mensuráveis',
      text: 'Nossa metodologia é 100% orientada a dados e resultados. Cada ação é planejada para gerar impacto real e comprovado no seu negócio.',
    },
  ];

  return (
    <section id="diferenciais" className="py-16 md:py-24 bg-cinza-escuro text-branco">
      <div className="container mx-auto px-6">
        <h2 className="text-3xl md:text-4xl font-bold font-poppins text-center mb-12 md:mb-16 text-azul-neon">
          Nossos Diferenciais Exclusivos para o Seu Sucesso.
        </h2>
        <div className="grid md:grid-cols-1 lg:grid-cols-3 gap-8">
          {differentials.map((differential, index) => (
            <div key={index} className="flex flex-col items-center text-center p-6 bg-gray-800 rounded-lg shadow-lg">
              {differential.icon}
              <h3 className="font-poppins text-2xl font-semibold mb-3">{differential.title}</h3>
              <p className="font-roboto-mono text-base">
                {differential.text}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default KeyDifferentialsSection;
