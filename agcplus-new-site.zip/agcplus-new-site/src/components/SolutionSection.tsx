import React from 'react';
import { Zap, BarChart2, Settings, Brain } from 'lucide-react'; // Ícones de exemplo

const SolutionSection = () => {
  const solutions = [
    {
      icon: <Zap size={40} className="text-azul-neon mb-4" />,
      title: 'Automação Inteligente',
      description: 'Automatizamos seus fluxos de marketing, vendas e atendimento, desde a captação e qualificação de leads até o follow-up, liberando sua equipe para focar em atividades estratégicas. (n8n, Python, Chatwoot)',
    },
    {
      icon: <BarChart2 size={40} className="text-azul-neon mb-4" />,
      title: 'Tráfego Pago Estratégico',
      description: 'Criamos e gerenciamos campanhas de alta performance, otimizando seu orçamento para atrair o público certo e maximizar seu ROI. (Meta Ads, Google Ads)',
    },
    {
      icon: <Settings size={40} className="text-azul-neon mb-4" />,
      title: 'Relatórios & Dashboards em Tempo Real',
      description: 'Tenha clareza total sobre seus resultados com dashboards intuitivos e dados atualizados em tempo real, permitindo decisões ágeis e assertivas.',
    },
    {
      icon: <Brain size={40} className="text-azul-neon mb-4" />,
      title: 'Estratégia & Branding',
      description: 'Construímos marcas fortes e posicionamentos de mercado que conectam e convertem.',
    },
  ];

  return (
    <section id="solucao" className="py-16 md:py-24 bg-cinza-escuro text-branco">
      <div className="container mx-auto px-6">
        <h2 className="text-3xl md:text-4xl font-bold font-poppins text-center mb-6 text-azul-neon">
          AGC+: Transformação Digital Sem Complexidade, Resultados Reais.
        </h2>
        <p className="font-roboto-mono text-lg text-center mb-12 md:mb-16 max-w-3xl mx-auto">
          Na AGC+, somos mais que uma agência. Somos seus parceiros estratégicos na jornada da transformação digital. Com tecnologia de ponta e inteligência de mercado, desvendamos o potencial da automação para que sua empresa não apenas cresça, mas prospere de forma sustentável e escalável.
        </p>
        <div className="grid md:grid-cols-2 gap-8">
          {solutions.map((solution, index) => (
            <div key={index} className="flex flex-col items-start p-6 bg-gray-800 rounded-lg shadow-lg">
              <div className="flex items-center mb-4">
                {solution.icon}
                <h3 className="font-poppins text-2xl font-semibold ml-4">{solution.title}</h3>
              </div>
              <p className="font-roboto-mono text-base">
                {solution.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default SolutionSection;
