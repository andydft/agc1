import React from 'react';
import { Clock, TrendingDown, Wind, HelpCircle } from 'lucide-react'; // Ícones de exemplo

const ProblemSection = () => {
  const problems = [
    {
      icon: <Clock size={40} className="text-azul-neon mb-4" />,
      text: 'Perda de tempo com tarefas repetitivas que poderiam ser automatizadas?',
    },
    {
      icon: <TrendingDown size={40} className="text-azul-neon mb-4" />,
      text: 'Dificuldade em qualificar leads e direcioná-los para a equipe de vendas?',
    },
    {
      icon: <Wind size={40} className="text-azul-neon mb-4" />, // Ícone 'dollar-sign' ou 'credit-card' seria mais apropriado para dinheiro voando
      text: 'Investimento em marketing sem clareza sobre o retorno real?',
    },
    {
      icon: <HelpCircle size={40} className="text-azul-neon mb-4" />,
      text: 'Falta de uma estratégia digital integrada que realmente gere resultados?',
    },
  ];

  return (
    <section id="problema" className="py-16 md:py-24 bg-cinza-escuro text-branco">
      <div className="container mx-auto px-6">
        <h2 className="text-3xl md:text-4xl font-bold font-poppins text-center mb-12 md:mb-16">
          Seu Crescimento Está Travado por Processos Manuais e Marketing Ineficiente?
        </h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {problems.map((problem, index) => (
            <div key={index} className="flex flex-col items-center text-center p-6 bg-gray-800 rounded-lg shadow-lg">
              {problem.icon}
              <p className="font-roboto-mono text-lg">
                {problem.text}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ProblemSection;
