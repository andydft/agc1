import Navbar from "@/components/Navbar";
import HeroSection from "@/components/HeroSection";
import ProblemSection from "@/components/ProblemSection";
import SolutionSection from "@/components/SolutionSection";
import KeyDifferentialsSection from "@/components/KeyDifferentialsSection";
import SocialProofSection from "@/components/SocialProofSection";
import FinalCTASection from "@/components/FinalCTASection";
import AppointmentFormSection from "@/components/AppointmentFormSection";
import Footer from "@/components/Footer";

export default function HomePage() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-between bg-cinza-escuro">
      <Navbar />
      <HeroSection />
      <ProblemSection />
      <SolutionSection />
      <KeyDifferentialsSection />
      <SocialProofSection />
      <FinalCTASection />
      <AppointmentFormSection />
      <Footer />
    </main>
  );
}
